Kapoor's Kitchen Analytics Project

This project includes:
- Descriptive analytics
- Diagnostic analytics
- Predictive modeling (Logistic Regression)
- Customer prediction feature

Upload your CSV dataset to run the app.

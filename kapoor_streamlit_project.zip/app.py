import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_curve
import matplotlib.pyplot as plt

st.title("Kapoor's Kitchen Analytics Dashboard")

file = st.file_uploader("Upload your dataset", type=["csv"])

if file:
    df = pd.read_csv(file)

    st.subheader("Dataset")
    st.write(df.head())

    st.subheader("Orders by Area")
    st.bar_chart(df.groupby("Area")["Orders"].sum())

    st.subheader("Correlation")
    st.write(df.corr(numeric_only=True))

    df["Target"] = df["Orders"].apply(lambda x: 1 if x > 5 else 0)

    X = df[["Income", "Visits", "Clicks"]]
    y = df["Target"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = LogisticRegression()
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)

    st.subheader("Model Performance")
    st.write("Accuracy:", accuracy_score(y_test, y_pred))
    st.write("Precision:", precision_score(y_test, y_pred))
    st.write("Recall:", recall_score(y_test, y_pred))
    st.write("F1 Score:", f1_score(y_test, y_pred))

    fpr, tpr, _ = roc_curve(y_test, model.predict_proba(X_test)[:,1])
    fig, ax = plt.subplots()
    ax.plot(fpr, tpr)
    ax.set_xlabel("FPR")
    ax.set_ylabel("TPR")
    st.pyplot(fig)

    st.subheader("Feature Importance")
    st.write(pd.DataFrame({
        "Feature": X.columns,
        "Importance": model.coef_[0]
    }))

    st.subheader("Predict New Customer")

    income = st.number_input("Income")
    visits = st.number_input("Visits")
    clicks = st.number_input("Clicks")

    if st.button("Predict"):
        result = model.predict([[income, visits, clicks]])
        st.write("Will Order" if result[0]==1 else "Will Not Order")
